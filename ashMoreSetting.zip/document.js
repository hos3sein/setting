1 = group ro faghat ba esm to user zakhire konm OK
2 = esm group taghir nemikone 
3 = user moghe register agar complete nabod pakesh konm az aval besazam  OK
4 = vaghti user request group mizane faghat esm group ro to pending save konm
5 = to pending user betone darkhast bezane group begire
6 = user kol request haee ke vase group zada ro bebine
7 = admin request haro bebine 
8 = admin request ro approve kone va ba fetch to user taraf sabt she faghat esmesh
9 = to hame service ha har masalan 10 min darkhast bezane group haye jadid dasht begire save kone to service khodesh
va system check authorize kone ~~ OK

10 = to har service baraye har route yek permission shakhte beshe





// ! bayad check group ro kashf konm chejory befahmam kodoma taghir karde hamonaro update konm